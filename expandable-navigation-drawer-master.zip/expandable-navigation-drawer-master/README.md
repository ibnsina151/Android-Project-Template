# expandable-navigation-drawer

Implement simple application containing navigation Drawer with expandableListView elements.

# Application description
<p>
In app you can see integrated navigation drawer with items containing different types of movie genres. Each item contains some (hard-coded) movie list related to the corresponding genre. When user clicks on one of the items the item will be expanded and the content of that item (actually it is list of the films of the given genre) will become visible. If user clicks on the expanded item the list of movies will be collapsed.  
</p>

<img src="https://cloud.githubusercontent.com/assets/11542701/10702255/d1556874-79c8-11e5-9f57-b4c604879033.png" width="240px" height="426px"></img>
